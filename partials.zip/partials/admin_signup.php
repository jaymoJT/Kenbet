<?php 
  if (isset($_POST['submit'])) {
    
    include_once 'connection.php';

    $name  = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $pwd   = mysqli_real_escape_string($conn, $_POST['pwd']);

    //error handlers
    //checking for empty fields

    if (empty($name) ||
        empty($phone) ||
        empty($pwd)
       ) {
       	 echo "  <script type=text/javascript >
                 alert('Fields are empty');
                   location.href='../member_signup.php?server=Empty fields!';
                </script> ";
    }
    	else {
    		//check if the credentials are already in the database
    		$sql = "SELECT * FROM admin WHERE phone = '$phone' ";
    		$result = mysqli_query($conn,$sql);
            $resultCheck = mysqli_num_rows($result);

            if ($resultCheck > 0) {
            	echo "<script type=text/javascript>
                       alert('The phone number is already in use');
                       location.href='../member_signup.php?server=Phone number taken'
            	      </script> ";
            	
            } else { 
            	//hashing the password
            	$hashedpwd = password_hash($pwd, PASSWORD_DEFAULT);

            	//insert the user into the database
            	$sql = "INSERT INTO admin ( name,phone,password )  
            	              VALUES     ('$name', '$phone', '$hashedpwd'); ";

            	mysqli_query($conn,$sql);
            	
            	echo "<script>
                     alert('Reistration successfull');
                     location.href='../admin.php'
                  	</script>";
            	
            }

    	}
    }

  	
  
else {
	header("Location: ../signp.php");
	exit();
}


?>