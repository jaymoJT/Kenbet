<?php

session_start();

if (isset($_POST['submit'])) {
	include_once 'connection.php';

	$phone = mysqli_real_escape_string($conn, $_POST['phone']);
	$pwd   = mysqli_real_escape_string($conn, $_POST['pwd']);

	//error handler
	//checking for empty fields
	if (empty($phone) || empty($pwd)) {
		echo "<script>
               alert('Some fields are empty!');
               location.href='../member_login.php';
		      </script> ";
		
	}else {
		$sql = "SELECT * FROM members WHERE phone ='$phone'";
		$result = mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);

		if ($resultCheck < 1) {
			echo "<script>
               alert('Not reistered member!');
               location.href='../member_login.php';
		      </script> ";
			
		} else{
			//checking if the user typed in a password that matches those in the system
			if ($row = mysqli_fetch_assoc($result)) { 
				//dehashing the password
				$hashedpwdCheck = password_verify($pwd,$row['password']);
				if ($hashedpwdCheck == false) {
					echo "<script>
                           alert('Wrong password!');
                           location.href='../member_login.php';
		                  </script> ";
				} elseif ($hashedpwdCheck == true) {
					//log in the user here

					$_SESSION['m_name']=$row['name'];
					$_SESSION['m_phone']=$row['phone'];

					header('Location: ../index.php?server=Login_success!');
					exit();


				}

			}
		}

	}





}else {
	header("Location:../member_login.php");
	exit();
}


?>