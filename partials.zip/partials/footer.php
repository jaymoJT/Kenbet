            <div class="footer-copy text-center">
                <div class="container">
                    <div class="row">
                        <div class="pull-left">
                            <span> Developed by <a href="https://www.facebook.com/jimmytechies/">Jitweb softwares</a>  2018  </span> 
                        </div> 
                        <div class="bottom-menu pull-right"> 
                            <ul> 
                                <li><a class="wow fadeInUp animated" href="index.html" data-wow-delay="0.2s">Home</a></li>
                               
                                <li><a class="wow fadeInUp animated" href="about.html" data-wow-delay="0.4s">About us</a></li>
                                <li><a class="wow fadeInUp animated" href="contact.html" data-wow-delay="0.6s">Contact</a></li>
                            </ul> 
                        </div>
                    </div>
                </div>
            </div>

</body>
</html>