<?php include 'connection.php';?>
<?php
 if (isset($_POST['submit']))
 {   

    $gdate  = mysqli_real_escape_string($conn,$_POST['gdate']); 
    $matches = mysqli_real_escape_string($conn,$_POST['matches']);
    $type = mysqli_real_escape_string($conn,$_POST['type']);
    $predictions = mysqli_real_escape_string($conn,$_POST['predictions']);


    //Error handlers
    //Check for empty fields..
    if (empty($gdate)|| 
        empty($matches) ||
        empty($type) ||
        empty($predictions)
        ) 
    {
         echo "  <script type=text/javascript >
                 alert('Fields are empty');
                   location.href='../post_games.php?server=Empty fields!';
                </script> ";
    }

    else {
        echo "  <script type=text/javascript >
                 alert('Game posted successfully');
                   location.href='../post_games.php?server=game posted successfully!';
                </script> ";

        
   
  }  

    $sql = "INSERT INTO games (MatchDate,matches,mtype,predictions)
                VALUES ('$gdate','$matches','$type','$predictions')";

    if (mysqli_query($conn, $sql))
     {
        echo "Game posted successfully. ";
    }

    else 
        {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }

    
     mysqli_close($conn);


    }
   

?>    