<div class="header-half header-social">
    <ul class="list-inline">
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
        	<input type="submit" name="submit" value="log out">
        </form>
    </ul>
</div>

<?php 
if (isset($_POST['submit'])) {
   session_start();
   session_unset();
   session_destroy();
    echo "  <script type=text/javascript >
              location.href='../index.php?server=Empty fields!';
            </script> ";
	
}

?>