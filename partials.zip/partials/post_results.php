<?php include 'connection.php';?>

<?php
 if (isset($_POST['submit']))
 {   

  $gdate = mysqli_real_escape_string($conn,$_POST['gdate']);
  $gmatch = mysqli_real_escape_string($conn,$_POST['gmatch']);
  $gpred = mysqli_real_escape_string($conn,$_POST['gpred']);
  $gresult = mysqli_real_escape_string($conn,$_POST['gresult']);


  //checking for empty fields
  if (empty($gdate) || empty($gmatch) || empty($gpred) || empty($gresult)) {

    echo "<script>
           alert('Some fields are empty');
           Location.href='../post_results.php?server=emptyfields!';
          </script>";
    
  }else {
    $sql ="INSERT INTO results (gdate, gmatch, predictions, outcome)
        VALUES ('$gdate','$gmatch','$gpred','$gresult')";

        if (mysqli_query($conn,$sql)) {

          header("Location:../post_results.php?server=Resultssuccess");
          
        } else {
          echo "Error:" . $sql. "<br>" .mysqli_erroe($conn);
        }

        mysqli_close($conn);
  }




  
 }
?>    