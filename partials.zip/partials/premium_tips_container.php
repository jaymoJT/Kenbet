<div class="container">
     
    <h2>Today's predictions</h2>
    <?php include 'views/premium_tips.php'; ?>
     
</div>