<nav class="navbar navbar-default ">
            <div class="container">
                <a href="vip.php">
                    <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#e25e00; color:#fff;">VIP</button>
                </a>
                <a href="vvip.php">
                   <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#e25e00; color:#fff;">VVIP</button>   
                </a>
                <a href="#">
                   <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#e25e00; color:#fff;">New subscribers (Today)</button>   
                </a>
                <a href="#">
                    <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#e25e00; color:#fff;">
                   Earning summaries
                </button>
                <a href="edit_games.php">
                    <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#e25e00; color:#fff;">Games
                </button>
                </a>
                <a href="edit_predictions.php">
                    <button type="reset" name="reset" value="Reset" class="button btn largesearch-btn" style="background-color:#e25e00; color:#fff;">
                   Results
                </button>
                </a>          
            </div><!-- /.container-fluid -->
</nav>