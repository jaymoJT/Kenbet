        <div class="header-connect" style="background-color:#540773; ">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-8  col-xs-12">
                        <div class="header-half header-call">
                            <p>
                                <span style="color:#fff;"><i class="pe-7s-call"></i> +254703109012</span>
                                <span style="color:#fff;"><i class="pe-7s-mail"></i> info@kenbet.co.ke</span>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-2 col-md-offset-5  col-sm-3 col-sm-offset-1  col-xs-12">
                        <?php
                          include 'header_auth2.php';
                         ?>
                    </div>
                </div>
            </div>
        </div>           