        <nav class="navbar navbar-default " style="color:#000;">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php" style="margin-top:-7%;"><img src="assets/img/icon.jpg" style="width:20%;">Kenbet</a>
                    
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse yamm" id="navigation">
                    
                    <ul class="main-nav nav navbar-nav navbar-right">
                        <li class="wow fadeInDown" data-wow-delay="0.1s">
                        <a href="index.php" style="color:green">
                        Home</a>
                        </li>
                        <li class="wow fadeInDown" data-wow-delay="0.1s">
                            <a href="premium_predictions.php" style="color:green;">Premium predictions</a>
                        </li>
                        <li class="wow fadeInDown" data-wow-delay="0.1s">
                            <a href="free_predictions.php" style="color:green;">Free predictions</a>
                        </li>
                        <li class="wow fadeInDown" data-wow-delay="0.1s"><a href="member_signup.php" style="color:green;">Join us</a></li>
                        
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
        <!-- End of nav bar -->