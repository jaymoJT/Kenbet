<div id="preloader">
    <div id="status">&nbsp;</div>
</div>