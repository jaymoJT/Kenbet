<div class="content-area single-property" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">   

                <div class="clearfix padding-top-40" >

                    <div class="col-md-8 single-property-content prp-style-1 ">
                        <div class="row">
                            <div class="light-slide-item">            
                                
                                      <ul id="image-gallery" class="gallery list-unstyled cS-hidden">
                                        <li data-thumb="assets/img/slide/pic1.jpg"> 
                                            <img src="assets/img/slide/pic1.jpg" />
                                        </li>
                                        <li data-thumb="assets/img/slide/pic2.jpg"> 
                                            <img src="assets/img/slide/pic2.jpg"/>
                                        </li>
                                        <li data-thumb="assets/img/slide/pic3.jpg"> 
                                            <img src="assets/img/slide/pic3.jpg"
                                        </li>
                                        <li data-thumb="assets/img/slide/bet5.jpg"> 
                                            <img src="assets/img/slide/bet5.jpg" />
                                        </li>                           
                                    </ul>
                                
                            </div>
                        </div>


                      <!--The section that contains the site's description-->
                      <div class="single-property-wrapper">
                           <h3><b> Welcome to Kenbet community</b></h3>
                              <p><b> We offer well analysed predictions for all the matches available across all betting websites; Sportpesa,Betin,Mcheza,Betyetu, Betway, Dafabet and all other websites in kenya via text message<b></p>

                      </div> 
                      <hr> 
                      <div class="single-property-wrapper" style="margin-top:5%; ">
                            <h3><b>Our subscription packages</b></h3>
                            <div class="col-sm-6">
                                <div class="card" style="width: 18rem;">
                                    <ul class="list-group list-group-flush">
                                      <li class="list-group-item" style="background-color:#540773;color:#fff;">VIP subscriptions</li>
                                      <li class="list-group-item">Daily @Ksh 250</li>
                                      <li class="list-group-item">weekly @Ksh 1500</li>
                                      <li class="list-group-item">Monthly @Ksh 7000</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card" style="width: 18rem;">
                                    <ul class="list-group list-group-flush">
                                      <li class="list-group-item" style="background-color:#540773;color:#fff;">VVIP subscriptions</li>
                                      <li class="list-group-item">Daily @Ksh 2000</li>
                                      <li class="list-group-item">Weekly @Ksh 12000</li>
                                      <li class="list-group-item">Monthly @Ksh 60000</li>
                                    </ul>
                                </div>
                            </div>                                                 
                        </div>
                      
                      <div class="single-property-wrapper" style="margin-top:10px; ">
                        <hr>
                            <h3><b>Our previous predictions</b></h3>
                            
                            <?php include 'views/results.php' ?>

                        </div>
                   
                    </div>


                    <div class="col-md-4 p0">
                      <aside class="sidebar sidebar-property blog-asside-right">
                        <div class="dealer-widget" style="background-color:#fff;">
                          <div class="dealer-content">
                            <div class="tm-search-box effect2">
                              <div class="panel panel-default sidebar-menu similar-property-wdg wow fadeInRight animated">
                                <div class="panel-heading">
                                  <h3 class="panel-title">Pay to subscribe</h3>
                                </div>

                                <!--Displaying the lipa na Mpesa sidebar-->
                                <div class="panel-body recent-property-widget">
                                  <div class="card" style="width: 18rem;">
                                    <img class="card-img-top" src="assets/img/slide/mpesa.jpg" alt="Card image cap">
                                         <div class="card-body">
                                              <p class="card-text" style="color:#000;">
                                                  1. Go to Lipa na Mpesa <br>
                                                  2. Buy goods and services<br>
                                                  3. Enter Till number<br>
                                              </p>
                                          </div>
                                    </div>
                                </div>
                                <div class="panel-heading">
                                  <h3 class="panel-title">Log in for predictions</h3>
                                </div>
                                <form name="mpsForm" action="partials/member_login.php" method="post" class="booking-form">
                                <div class="tm-form-inner">
                                <div class="form-group" style="color:#000;">
                                    <label>Your Phone Number</label>
                                    <input type="number" class="form-control" name="phone" placeholder="Your Mpesa phone number">
                                </div>                
                                <div class="form-group" style="color:#000;">
                                    <label>Password</label>
                                    <input type="password" class="form-control" name="pwd" placeholder="Mpesa confirmation code sfter paying for subscription">
                                </div>
                                </div>                                                   
                                <div class="form-group tm-yellow-gradient-bg text-center">
                                        <button type="submit" name="submit" value="send" class="tm-yellow-btn" style="background-color:#4a763c;">Log in</button>
                                </div>  
                                </form>                
                              </div>  
                            </div>               
                          </div>     
                        </div>
                      </aside>
                    </div>                                                  
                </div>
                </div>
            </div>
        </div>

