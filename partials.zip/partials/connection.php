<?php 

   $servername = "localhost";
   $username   = "kenbetco_jitwebs";
   $password   = "BBIT/7949/1/1694";
   $dbname     = "kenbetco_kenbet";

   //creating connection
   $conn = mysqli_connect ($servername, $username, $password, $dbname);

   //confirming connection
   if (!$conn) 
   {
    "Connection failed:" . mysqli_connect_error();
   }

?>
