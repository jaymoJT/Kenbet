<?php
//this session confirms if the user has logged in as the admin
session_start();

 if (!isset($_SESSION['m_admin'])) {
  header("Location:admin.php?server=Mustlogin");
  exit();
}
else{
	header("Location:admin_dashboard.php");
	exit();
}

?>
