<div class="header-half header-social">
    <ul class="list-inline">
        <li><a href="#" style="color:#fff;"><i class="fab fa-facebook"></i></a></li>
        <li><a href="#" style="color:#fff;"><i class="fab fa-twitter-square"></i></a></li>
        <li><a href="../member_login.php" style="color:#fff;" >Log in</a> </li>
        <li><a href="../member_signup.php" style="color:#fff;">Join us </a> </li>
    </ul>
</div>