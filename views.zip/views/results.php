<table class="table table-striped">                     
    <div class="table responsive">
        <thead>
            <tr style="color:#000;">
              <th>Game Date</th>
              <th>Match</th>
              <th>Predictions</th>
              <th>Outcome</th>
            </tr>
        </thead>
        <tbody>

<?php 
 include './partials/connection.php';

 
 $sql = "SELECT * FROM results";

 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
 	while($row = $result->fetch_assoc()) {
 		echo '<tr>
            <td scope="row" style="color:#112187;">'  .$row["gdate"]. '</td>
            <td style="background-color:green;color:#fff;" >'.$row["gmatch"] .'</td>
            <td style="color:#112187;">'.$row["predictions"].'</td>
            <td style="background-color:green;color:#fff;">'.$row["outcome"].'</td>
          </tr>';
 	}
 }
 else {
 	echo '0 results';
 }
 	
 

?>

       </tbody>
    </div>
</table>

