<table class="table table-striped">                     
    <div class="table responsive">
        <thead>
            <tr style="color:#000;">
              <th>Match Date</th>
              <th>Matches</th>
              <th>Predictions</th>
              <th>Edit</th>
            </tr>
        </thead>
        <tbody>

<?php 
 include './partials/connection.php';

 $d = date("y/m/d");
 $sql = "SELECT MatchDate, matches, predictions FROM games  WHERE mtype =
        'Premium' AND MatchDate = '$d'";

 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
 	while($row = $result->fetch_assoc()) {
 		echo '<tr>
            <td scope="row" style="color:#112187;">'  .$row["MatchDate"]. '</td>
            <td style="background-color:green;color:#fff;" >'.$row["matches"] .'</td>
            <td style="color:#112187;"> '  .$row["predictions"] .'</td>
            <td><button ahref="results.php">Edit</button></td>
          </tr>';
 	}
 }
 else {
 	echo '0 results';
 }
 	
 

?>

       </tbody>
    </div>
</table>

