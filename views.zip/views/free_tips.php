<table class="table table-striped">                     
    <div class="table responsive">
        <thead>
            <tr style="color:#000;">
              <th>Match Date</th>
              <th>Matches</th>
              <th>Predictions</th>
            </tr>
        </thead>
        <tbody>

<?php 
 include './partials/connection.php';


 $sql = "SELECT MatchDate, matches, predictions FROM games  WHERE mtype =
        'Free'";

 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
 	while($row = $result->fetch_assoc()) {
 		echo '<tr>
                  <td scope="row">'  .$row["MatchDate"]. '</td>
                             <td>'   .$row["matches"] .'</td>
                             <td> '  .$row["predictions"] .'</td>
                </tr>';
 	}
 }
 else {
 	echo '0 results';
 }
 	
 

?>

       </tbody>
    </div>
</table>

